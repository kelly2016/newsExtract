

import tensorflow as tf
from tensorflow import keras
# from keras.callbacks import TensorBoard ,ModelCheckpoint, ReduceLROnPlateau, EarlyStopping
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.inception_v3 import InceptionV3
from tensorflow.keras.applications.vgg16 import VGG16 
from tensorflow.keras.applications.resnet50 import ResNet50 
from tensorflow.keras.applications.xception import Xception
from tensorflow.keras.applications.nasnet import NASNetMobile
from tensorflow.keras.applications.densenet import DenseNet201
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.layers import Dropout, Flatten, Dense, GlobalAveragePooling2D, Average, Input, Concatenate, GlobalMaxPooling2D

import cv2
import datetime
import numpy as np
import os


HOME = '/data/yangbo/9.1-cnn/'
# HOME = '/Users/yangbo/working/机器学习/testPython/9.1_cnn/'
print('Import OK')

def create_model(net_type):
    # weights='imagenet'会从网站自动下载在imagenet训练好的权重文件
    # 也可以自己网上找到权重文件下载后，在weights参数中指定文件路径即可ç
    if net_type == 'ResNet50':
        base_model = ResNet50(weights='imagenet',include_top=False)
    if net_type == 'VGG16':
        # base_model = VGG16(weights='imagenet',include_top=False)
        weight_path = HOME + 'vgg16_weights_tf_dim_ordering_tf_kernels_notop.h5'
        base_model = VGG16(weights=weight_path ,include_top=False)                
    if net_type == 'InceptionV3':
        # base_model = InceptionV3(weights='imagenet',include_top=True)
        weight_path = HOME + 'inception_v3_weights_tf_dim_ordering_tf_kernels_notop.h5'
        base_model = InceptionV3(weights='imagenet',include_top=True)        
    if net_type == 'DenseNet201':
        weight_path = HOME + 'densenet201_weights_tf_dim_ordering_tf_kernels_notop.h5'
        # base_model = DenseNet201(weights=weight_path,include_top=False)
        base_model = DenseNet201(include_top=False, 
                                 weights=weight_path,
                                 input_tensor=None, 
                                 input_shape=(100, 100, 3), 
                                 pooling='avg')
        

    # x = base_model.output
    # x = keras.layers.GlobalAveragePooling2D()(x)
    # x = keras.layers.Dense(1024, activation='relu')(x)
    # x = keras.layers.Dropout(0.5)(x)

    x = base_model.get_layer(index=-1).output
    x = keras.layers.Dropout(0.5)(x)

    predictions = keras.layers.Dense(2, activation='softmax')(x)
    model = keras.Model(inputs=base_model.input, outputs=predictions)  

    # 指定卷积层是否训练，如果false则只是训练全链接层
    for layer in base_model.layers:  
        layer.trainable = True #False     
    
    model.compile(optimizer=Adam(lr=0.0001, decay=0.00001),  
              loss='categorical_crossentropy',
              metrics=['accuracy'])

    return model

def train(train_data_dir, validation_data_dir):
    img_height, img_width = 100, 100 
    nb_train_samples = 10000
    nb_validation_samples = 10000 
    epochs = 1
    batch_size = 32
    
    train_datagen = ImageDataGenerator(
            rescale=1./255, 
        )

    val_datagen = ImageDataGenerator(rescale=1./255)

    train_generator = train_datagen.flow_from_directory(
            train_data_dir,
            target_size=(img_height, img_width),
            batch_size=32,
            class_mode='categorical')
    print('train_generator:', train_generator)

    validation_generator = val_datagen.flow_from_directory(
            validation_data_dir,
            target_size=(img_height, img_width),
            batch_size=32,
            class_mode='categorical')
    print('validation_generator:', validation_generator)
    
    checkpoint_path = "model.h5"
    checkpoint = keras.callbacks.ModelCheckpoint(checkpoint_path, 
                                 monitor='val_acc', 
                                 verbose=2,
                                 save_weights_only=False, 
                                 save_best_only=True, 
                                 mode='max')
    tbCallBack = keras.callbacks.TensorBoard(log_dir='./logs')
    
    # model = create_model('VGG16')
    # model = create_model('InceptionV3')
    model = create_model('DenseNet201')
    model.summary()

    model.fit_generator(
            train_generator,
            steps_per_epoch=nb_train_samples // batch_size,
            epochs=epochs,
            validation_data=validation_generator,
            validation_steps=nb_validation_samples // batch_size,
            callbacks=[checkpoint,tbCallBack]
            )
    
if __name__=='__main__':
    # train和val下面的目录结构是一样的
    #  比如
    #  ./train/
    #        /dog
    #        /cat
    #   ./val/
    #        /dog
    #        /cat
    # dog和cat目录下分别是狗和猫的图片
    root_dir = HOME + 'dogcat_data/'
    targetTrainPath = root_dir + 'train/'
    targetValPath = root_dir + 'val/'
    
    train(targetTrainPath, targetValPath)

    
    